package com.example.xslt;

public class Constants {

    public static final String CSV = ".csv";

    public static final String XLSX = ".xlsx";

    public static final String XLS = ".xls";
}
