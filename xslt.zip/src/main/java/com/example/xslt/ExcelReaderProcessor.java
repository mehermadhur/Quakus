package com.example.xslt;

import java.util.HashMap;

//import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;


import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Component
@Data
@Slf4j
public class ExcelReaderProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
    	
    XSLTRoute.XLS_CONFIG_MAP.putAll(exchange.getIn().getBody(HashMap.class));
    exchange.getMessage().setBody("Configuration Placed", String.class);
    System.out.println("Configuration Placed -> {}");
    }
     
}
