package com.example.xslt;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

 
import org.apache.camel.Body;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component("excelTransactionProcessor")
@Slf4j
public class ExcelTransactionProcessor {
	private static final Logger logger = LoggerFactory.getLogger(ExcelTransactionProcessor.class);
 

	private static Workbook getWorkbook(File file) throws IOException {
		// Workbook workbook = null;
		FileInputStream fis = new FileInputStream(file);
		// workbook = new HSSFWorkbook(fis);
		Workbook workbook = new HSSFWorkbook(fis);
		return workbook;
	}

	private static Object getCellValue(Cell cell) {

		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue();

		case BOOLEAN:
			return cell.getBooleanCellValue();

		case NUMERIC:
			DataFormatter dataFormatter = new DataFormatter();
			String cellStringValue = dataFormatter.formatCellValue(cell);
			return cellStringValue;
		case FORMULA:
			return cell.getCellFormula();
		default:
			break;
		}
		return null;
	}

	private void transactionObjectResolver(Row row, Map<String,String> mp) {

		try {
			mp.put(getCellValue(row.getCell(0)).toString(), getCellValue(row.getCell(1)).toString());
		} catch (Exception e) {
			logger.info(":::::: Error in transaction Upload row ::::::");
		}

 
	}

	public  Map<String,String> processExcelData(@Body File file) throws IOException {

		String batchId = Utility.batchIds();
		Map<String,String> mp = new HashMap<>();
		try {
			// Workbook workbook;
			DataFormatter formatter = new DataFormatter(); // creating formatter using the default locale

			
			Workbook workbook = null;
			if (file != null && file.getPath().endsWith("xls")) {
				FileInputStream fis = new FileInputStream(file);
				workbook = new HSSFWorkbook(fis);
			} else {
				// FileInputStream fis=new FileInputStream(file);
				workbook = new XSSFWorkbook(file);
			}
			// workbook = getWorkbook(file);

			Sheet firstSheet = workbook.getSheetAt(0);// GET FIRST SHEET
			Iterator<Row> rowIterator = firstSheet.iterator();

			while (rowIterator.hasNext()) {
				boolean errorFound = false;
				String cellErrorMsg = "";

				Row nextRow = rowIterator.next();
				if (nextRow.getRowNum() == 0) {// SKIP HEADERS(FIRST ROW)
					continue;
				}

				if (isRowEmpty(nextRow)) {// row is empty
					continue;
				}

				RowError error = new RowError();
				int lastCellNum = nextRow.getLastCellNum();
				for (int cn = 0; cn <= lastCellNum; cn++) {
					Cell c = nextRow.getCell(cn);
				}
				 transactionObjectResolver(nextRow, mp);
				 
			}
			System.out.println("Map Data:::"+mp);
		} catch (Exception e) {
			log.error("exception occurred while reading  file " + e.getLocalizedMessage(), e);
		}
      return mp;
	}

	private static boolean isRowEmpty(Row row) {
		if (row == null) {
			return true;
		}
		if (row.getLastCellNum() <= 0) {
			return true;
		}
		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			if (cell != null && cell.getCellType() != CellType.BLANK)
				return false;
		}
		return true;
	}

}