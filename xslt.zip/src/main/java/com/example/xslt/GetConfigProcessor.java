package com.example.xslt;

import java.util.HashMap;
 

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Component
@Data
@Slf4j
public class GetConfigProcessor implements Processor {
 
	@Override
    public void process(Exchange exchange) throws Exception {
    	  System.out.println("In process -> {}");
    	String payload =(String) exchange.getIn().getBody();
    	 StringBuffer updatedpayLoad = new StringBuffer();
    	
    	 System.out.println("payload -> {}::"+payload);
    	HashMap<String,String>  mp = new HashMap<String, String>();
    			mp.putAll(XSLTRoute.XLS_CONFIG_MAP);
    			if(payload !=null ) {
    			for(String key : mp.keySet()) {
    				if(payload.contains(key)) {
    					updatedpayLoad.append(payload.replaceAll(key, mp.get(key)));    					 
    				}
    			}
    			}
    	
       System.out.println("payload After -> {}:::"+updatedpayLoad);
       exchange.getIn().setBody(payload); 
    }
     
}
