package com.example.xslt;

import java.util.Date;
import java.util.HashMap;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class XSLTRoute extends RouteBuilder {

	@Autowired
	Environment env;

	/*
	 * @Qualifier("dataSource")
	 * 
	 * @Autowired DataSource dataSource;
	 * 
	 * @Autowired BuildSQLProcessor sqlProcessor;
	 */
	@Autowired
	SuccessProcessor successProcessor;

	@Autowired
	GetConfigProcessor getConfigProcessor;

	@Autowired
	ExcelReaderProcessor excelReaderProcessor;

	/*
	 * @Autowired MailProcessor mailProcessor;
	 */
	 @Autowired 
	 private ExcelTransactionProcessor excelConverterBean;
 
	 
		public static final HashMap<String,String> XLS_CONFIG_MAP = new HashMap<String,String> ();

	@Override
	public void configure() throws Exception {

		/* DataFormat bindy = new BindyCsvDataFormat(InitialDataVO.class); */

		/*
		 * errorHandler(deadLetterChannel(
		 * "log:errorInRoute?level=ERROR&showProperties=true").maximumRedeliveries(3).
		 * redeliveryDelay(3000)
		 * .backOffMultiplier(2).retryAttemptedLogLevel(LoggingLevel.ERROR));
		 * 
		 * onException(PSQLException.class).log(LoggingLevel.
		 * ERROR,"PSQLException in Route: ${body}")
		 * .maximumRedeliveries(3).redeliveryDelay(3000).backOffMultiplier(2).
		 * retryAttemptedLogLevel(LoggingLevel.ERROR);
		 * 
		 * onException(DataException.class).log(LoggingLevel.
		 * ERROR,"DataException in Route: ${body}").process(mailProcessor)
		 * .maximumRedeliveries(3).redeliveryDelay(3000).backOffMultiplier(2).
		 * retryAttemptedLogLevel(LoggingLevel.ERROR);
		 */
		
		/*
		 * from("{{startRoute}}") .log("Timer invoked and the message is " +
		 * env.getProperty("message")) .choice()
		 * .when(header("env").isNotEqualTo("mock"))
		 * .pollEnrich("{{fromRoute}}").otherwise()
		 * .log("mock env flow and the body is ${body}").end().to("{{toRoute1}}") //
		 * .split(body()) // .streaming()
		 * 
		 * .bean(excelConverterBean, "processExcelData")
		 * .log(String.format("completed excel file upload on %s", new Date()))
		 * .log("Unmarshelled -> ${body}") .process(excelReaderProcessor) .end();
		 */
		
		  from("file:data/config") .log("File configuration  Read and the message is ")		
		  .bean(excelConverterBean, "processExcelData"). process(excelReaderProcessor);
		 
		
		  from("{{fromRoute}}").log("File Read XSLT invoked and the message is " )
		  .convertBodyTo(String.class)		  
		  .process(getConfigProcessor).to("{{toRoute2}}");
		 

	}

}
