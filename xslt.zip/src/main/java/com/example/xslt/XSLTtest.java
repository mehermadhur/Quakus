package com.example.xslt;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.csv.CsvDataFormat;
import org.apache.commons.csv.CSVFormat;
import org.springframework.stereotype.Component;

@Component
public class XSLTtest extends RouteBuilder {
    
    public void configure() {
        
        CsvDataFormat csv = new CsvDataFormat();
        csv.setFormat(CSVFormat.EXCEL);
        
        from("file://D://inbox")
            .unmarshal(csv)
            .log("Reached ${body}")
            .marshal(csv)
            .to("file://D://outbox?fileName=test.xlsx");
    }
}