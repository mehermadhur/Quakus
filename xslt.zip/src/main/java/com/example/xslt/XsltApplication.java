package com.example.xslt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XsltApplication {

	public static void main(String[] args) {
		SpringApplication.run(XsltApplication.class, args);
	}

}
